// pages/another/cust-swiper/index.js
var t = require("../../subpages/utils/config.js"),c = t.dataList,a = t.dataList.length, u = Math.floor(Math.random() * a),b = require("../../subpages/utils/guiHelper.js");

Page({
  data: {
    click: false, //是否显示弹窗内容
    option: false, //显示弹窗或关闭弹窗的操作动画
    show_menu: false,
    currIndex: "",
    swiperList: [
      {
        link:"/subpages/page5/pintustart/pintustart",
        type: 'image',
        url: 'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/拼图.png'
      }, {
        link:"/subpages/page3/vx/vx",
        type: 'image',
        url: 'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/猜灯谜.png',
      }, {
        link:"/subpages/page7/examstart/examstart",
        type: 'image',
        url: 'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/硬核答题.png'
      }, {
        link:"/subpages/page2/yuludetail/yuludetail?id=" + c[u].id,
        type: 'image',
        url: 'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/每日科普.png'
      }, {
        link:"/subpages/page4/LLKstart/LLKstart",
        type: 'image',
        url: 'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/连连看.png'
      }, {
        link:"/subpages/page6/gamestart/gamestart",
        type: 'image',
        url: 'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/翻牌.png'
      }, {
        link:"/subpages/page8/tujian/tujian",
        type: 'image',
        url: 'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/舰船图鉴.png'
      },
     
    ],
    
  },
  showMenu() {
    let { show_menu } = this.data;
    this.setData({
      show_menu: !show_menu,
      currIndex: "",
    });
  },
  clickActive(e) {
    let { index } = e.currentTarget.dataset;
    if (this.data.currIndex === index || index === undefined) return false;
    this.setData({
      currIndex: index,
    });
  },
  onLoad: function (options) {
    this.tauchSwiper('swiperList');
  },
  onShow: function () {

  },
  // 初始化tauchSwiper
  tauchSwiper(name) {
    let list = this.data[name];
    for (let i = 0; i < list.length; i++) {
      // Math.abs(x) 函数返回指定数字 “x“ 的绝对值
      list[i].zIndex = parseInt(list.length / 2) + 1 - Math.abs(i - parseInt(list.length / 2))
      list[i].mLeft = i - parseInt(list.length /2)
    }
    this.setData({
      swiperList: list
    })
  },
  // tauchSwiper触摸开始
  tauchStart(e) {
    this.setData({
      tauchStart: e.touches[0].pageX
    })
  },
  // tauchSwiper计算方向
  tauchMove(e) {
    this.setData({
      direction: e.touches[0].pageX - this.data.tauchStart > 0 ? 'top' : 'bottom'
    })
  },
  // tauchSwiper计算滚动
  tauchEnd(e) {
    let direction = this.data.direction;
    let list = this.data.swiperList;
    if (direction == 'top') {
      let mLeft = list[0].mLeft;
      let zIndex = list[0].zIndex;
      for (let i = 1; i < list.length; i++) {
        list[i - 1].mLeft = list[i].mLeft
        list[i - 1].zIndex = list[i].zIndex
      }
      list[list.length - 1].mLeft = mLeft;
      list[list.length - 1].zIndex = zIndex;
      this.setData({
        swiperList: list
      })
    } else {
      let mLeft = list[list.length - 1].mLeft;
      let zIndex = list[list.length - 1].zIndex;
      for (let i = list.length - 1; i > 0; i--) {
        list[i].mLeft = list[i - 1].mLeft
        list[i].zIndex = list[i - 1].zIndex
      }
      list[0].mLeft = mLeft;
      list[0].zIndex = zIndex;
      this.setData({
        swiperList: list
      })
    }
  },
  tap(e){
    b.audioPlay(0)
    let item =this.data
    wx.navigateTo({
      url:item.link,
    })
  },
  // 用户点击显示弹窗
  clickPup: function() {
    let _that = this;
    if (!_that.data.click) {
      _that.setData({
        click: true,
      })
    }

    if (_that.data.option) {
      _that.setData({
        option: false,
      })

      // 关闭显示弹窗动画的内容，不设置的话会出现：点击任何地方都会出现弹窗，就不是指定位置点击出现弹窗了
      setTimeout(() => {
        _that.setData({
          click: false,
        })
      }, 500)


    } else {
      _that.setData({
        option: true
      })
    }
  },


})