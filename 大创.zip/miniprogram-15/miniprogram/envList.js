const envList = [{"envId":"cloud1-0gyoose47fbc4007","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}