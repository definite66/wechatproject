//logs.js
var b = require("./../../utils/guiHelper.js")
var util = require('../../utils/util.js')
Page({
  data: {
    logs: []
  },
  onLoad: function () {
    this.setData({
      logs: (wx.getStorageSync('maxscore') || [])
    })
  },
  return: function () {
    b.audioPlay()
    wx.navigateTo({
      url: '/page6/gamestart/gamestart'
    })
  }
})
