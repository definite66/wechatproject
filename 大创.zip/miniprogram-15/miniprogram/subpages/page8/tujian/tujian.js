var z = require("./../../utils/guiHelper.js")
const app=getApp()
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    page_show:false,
    navHeight: '',
    menuButtonInfo: {},
    searchMarginTop: 0, // 搜索框上边距
    searchWidth: 0, // 搜索框宽度
    searchHeight: 0 ,// 搜索框高度
    lists: [
      "中","中", "美", "英", "法", "俄", "日", "德", "意"
    ],
    lists_r0: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰", "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],lists_r1: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰",  "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],
    lists_r2: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰", "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],
    lists_r3: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰",  "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],lists_r4: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰", "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],
    lists_r5: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰",  "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],lists_r6: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰",  "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],lists_r7: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰",  "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],lists_r8: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰",  "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],lists_r1_r1: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰",  "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],lists_r1_r2: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰", "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],lists_r1_r3: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰",  "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],lists_r1_r4: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/宁海.png',link:'https://baike.baidu.com/item/%E5%AE%81%E6%B5%B7%E7%BA%A7%E8%BD%BB%E5%B7%A1%E6%B4%8B%E8%88%B0?fromtitle=%E5%AE%81%E6%B5%B7%E5%8F%B7%E5%B7%A1%E6%B4%8B%E8%88%B0&fromid=3291282&fromModule=lemma_search-box'}
    ],lists_r1_r5: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/抚顺.png',link:'https://baike.baidu.com/item/%E6%8A%9A%E9%A1%BA%E5%8F%B7%E9%A9%B1%E9%80%90%E8%88%B0?fromModule=lemma_search-box'},
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/鞍山.png',link:'https://baike.baidu.com/item/%E9%9E%8D%E5%B1%B1%E5%8F%B7%E9%A9%B1%E9%80%90%E8%88%B0?fromModule=lemma_search-box'}
    ],lists_r2_r1: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/埃塞克斯.png',link:'https://baike.baidu.com/item/%E5%9F%83%E5%A1%9E%E5%85%8B%E6%96%AF%E5%8F%B7%E8%88%AA%E7%A9%BA%E6%AF%8D%E8%88%B0/4809880?fromModule=lemma_search-box'},
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/企业.png',link:'https://baike.baidu.com/item/%E4%BC%81%E4%B8%9A%E5%8F%B7%E8%88%AA%E7%A9%BA%E6%AF%8D%E8%88%B0/32607?fromModule=lemma_search-box'},
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/兰利.png',link:'https://baike.baidu.com/item/%E5%85%B0%E5%88%A9%E5%8F%B7%E8%88%AA%E7%A9%BA%E6%AF%8D%E8%88%B0/10860536?fromModule=disambiguation'}
    ],lists_r2_r2: [
      "航空母舰","航空母舰", "战列舰", "重巡洋舰", "轻巡洋舰", "驱逐舰", "护航驱逐舰",  "护卫舰", "小型护卫舰", "潜舰", "巡逻舰", "巡逻艇", "驱潜艇", "鱼雷快艇", "飞弹快艇", "巡逻快艇", "炮艇", "两栖攻击舰", "船坞登陆舰", "战车登陆舰", "中型登陆舰", "步兵登陆艇", "通用登陆艇", "机械登陆艇", "车辆人员登陆艇", "舰队扫雷舰", "远洋扫雷舰", "猎雷舰", "海岸扫雷艇", "近岸扫雷艇", "小型扫雷艇", "油弹补给舰", "驱逐母舰", "潜艇母舰", "弹药运输舰", "运输舰", "轻型运输舰", "测量舰", "运油舰", "汽油运送舰", "汽油运送舰","运货船","运煤船","修理舰","救难舰","潜艇救难舰","医院船","辅助拖船","舰队拖船","破冰船"
    ],lists_r2_r3: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/印第安纳波利斯.png',link:'https://baike.baidu.com/item/%E5%8D%B0%E7%AC%AC%E5%AE%89%E7%BA%B3%E6%B3%A2%E5%88%A9%E6%96%AF%E5%8F%B7%E5%B7%A1%E6%B4%8B%E8%88%B0?fromModule=lemma_search-box'}
    ],lists_r2_r5: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/弗莱彻.png',link:'https://baike.baidu.com/item/%E5%BC%97%E8%8E%B1%E5%BD%BB%E7%BA%A7%E9%A9%B1%E9%80%90%E8%88%B0?fromModule=lemma_search-box'}
    ],lists_r2_r6: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/埃尔德里奇.png',link:'https://baike.baidu.com/item/%E8%B4%B9%E5%9F%8E%E5%AE%9E%E9%AA%8C/1843458?fromModule=search-result_lemma-recommend'}
    ],lists_r2_r9: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/大青花鱼.png',link:'https://baike.baidu.com/item/%E5%A4%A7%E9%9D%92%E8%8A%B1%E9%B1%BC%E5%8F%B7%E6%BD%9C%E8%89%87?fromModule=lemma_search-box'}
    ],lists_r3_r1: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/皇家方舟.png',link:'https://baike.baidu.com/item/%E7%9A%87%E5%AE%B6%E6%96%B9%E8%88%9F%E5%8F%B7%E8%88%AA%E7%A9%BA%E6%AF%8D%E8%88%B0/20794508?fromModule=lemma_search-box'}
    ],lists_r3_r3: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/埃克塞特.png',link:'https://baike.baidu.com/item/%E5%9F%83%E5%85%8B%E5%A1%9E%E7%89%B9%E5%8F%B7%E9%87%8D%E5%B7%A1%E6%B4%8B%E8%88%B0?fromModule=lemma_search-box'}
    ],lists_r3_r4: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/贝尔法斯特.png',link:'https://baike.baidu.com/item/%E8%B4%9D%E5%B0%94%E6%B3%95%E6%96%AF%E7%89%B9%E5%8F%B7%E5%B7%A1%E6%B4%8B%E8%88%B0?fromModule=lemma_search-box'}
    ],lists_r4_r2: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/厌战.png',link:'https://baike.baidu.com/item/%E5%8E%8C%E6%88%98%E5%8F%B7%E6%88%98%E5%88%97%E8%88%B0?fromModule=lemma_search-box'}
    ],lists_r5_r4: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/阿芙乐尔.png',link:'https://baike.baidu.com/item/%E9%98%BF%E8%8A%99%E4%B9%90%E5%B0%94%E5%8F%B7%E5%B7%A1%E6%B4%8B%E8%88%B0/1187448?fromModule=lemma_search-box'}
    ],lists_r6_r1: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/赤城.png',link:'https://baike.baidu.com/item/%E8%B5%A4%E5%9F%8E%E5%8F%B7%E8%88%AA%E7%A9%BA%E6%AF%8D%E8%88%B0?fromModule=lemma_search-box'}
    ],lists_r6_r2: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/大和.png',link:'https://baike.baidu.com/item/%E5%A4%A7%E5%92%8C%E5%8F%B7%E6%88%98%E5%88%97%E8%88%B0?fromModule=lemma_search-box'}
    ],lists_r6_r4: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/阿贺野.png',link:'https://baike.baidu.com/item/%E9%98%BF%E8%B4%BA%E9%87%8E%E7%BA%A7%E8%BD%BB%E5%B7%A1%E6%B4%8B%E8%88%B0?fromModule=lemma_search-box'}
    ],lists_r7_r2: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/俾斯麦.png',link:'https://baike.baidu.com/item/%E4%BF%BE%E6%96%AF%E9%BA%A6%E5%8F%B7%E6%88%98%E5%88%97%E8%88%B0/164923?fromtitle=%E4%BF%BE%E6%96%AF%E9%BA%A6&fromid=2225317'}
    ],lists_r8_r2: [
      {url:'cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images8/tujian/加富尔伯爵.png',link:'https://baike.baidu.com/item/%E5%8A%A0%E5%AF%8C%E5%B0%94%E4%BC%AF%E7%88%B5%E7%BA%A7%E6%88%98%E5%88%97%E8%88%B0?fromModule=lemma_search-box'}
    ],
    indexId: 0,
    indexIdr0: 0,
    indexIdr0r0:0,
  },
  out(e){
    z.audioPlay()
    console.log(e.target.dataset.link)
    wx.navigateTo({
      url: '/subpages/page/out/out?param=e.target.dataset.link'
    })
  },
  tap(e) {
    wx.reLaunch({ 
      url: '/pages/index/index',
    })
  },
  // 左侧点击事件
  jumpIndex(e) {
    let index = e.currentTarget.dataset.menuindex
    let that = this
    that.setData({
      indexId: index
    });
  },

  jumpIndexR0(e) {
    let index = e.currentTarget.dataset.menuindex
    let that = this
    that.setData({
      indexIdr0: index
    });
  },
  jumpIndexR0R0(e) {
    let index = e.currentTarget.dataset.menuindex
    let that = this
    that.setData({
      indexIdr0r0: index
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          winHeight: res.windowHeight
        });
      }
    });
    var systeminfo=wx.getSystemInfoSync()
    //console.log(systeminfo.windowHeight)
    this.setData({
      movehight:systeminfo.windowHeight,
      movehight2:systeminfo.windowHeight-100
    })
 
    this.setData({
      menuButtonInfo: wx.getMenuButtonBoundingClientRect()
    })
    console.log(this.data.menuButtonInfo)
    const { top, width, height, right } = this.data.menuButtonInfo
    wx.getSystemInfo({
      success: (res) => {
        const { statusBarHeight } = res
        const margin = top - statusBarHeight
        this.setData({
          navHeight: (height + statusBarHeight + (margin * 2)),
          searchMarginTop: statusBarHeight + margin, // 状态栏 + 胶囊按钮边距
          searchHeight: height,  // 与胶囊按钮同高
          searchWidth: right - width -20// 胶囊按钮右边坐标 - 胶囊按钮宽度 = 按钮左边可使用宽度
        })
      }
    })
  },
 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
 
  },
 
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
 
  },
 
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
 
  },
 
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
 
  },
 
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
 
  },
 
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
 
  },
 
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
 
  }
})

