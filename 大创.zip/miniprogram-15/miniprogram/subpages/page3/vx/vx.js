var e = require("./../../utils/guiHelper.js"), n = require("./../../utils/questionHandler.js");
const backgroundAudioManager = wx.getBackgroundAudioManager()
backgroundAudioManager.src ='https://636c-cloud1-0gyoose47fbc4007-1324810507.tcb.qcloud.la/images3/%E7%81%AF%E8%B0%9C.mp3?sign=35c1674c097714d38a8e6f87d44d318e&t=1710755033'
// 背景音乐循环的方法
// 1、onEnded监听播放自然结束
backgroundAudioManager.onEnded(function() {
  // 2、必须重新设置src才能循环之后会自动播放
backgroundAudioManager.src ='https://636c-cloud1-0gyoose47fbc4007-1324810507.tcb.qcloud.la/images3/%E7%81%AF%E8%B0%9C.mp3?sign=35c1674c097714d38a8e6f87d44d318e&t=1710755033'})
getApp();

Page({
    data: {},
    player(audio) {
        var that = this
        //title不写或放空会报错哦，即使不报错ios系统会不播放，所以必须加
        audio.title = 'dengmi'
     
        //这点需知微信小程序上线不能超过2M,音乐文件会很大，所以要放在服务器上才可以
        audio.src = 'https://636c-cloud1-0gyoose47fbc4007-1324810507.tcb.qcloud.la/images3/%E7%81%AF%E8%B0%9C.mp3?sign=35c1674c097714d38a8e6f87d44d318e&t=1710755033'
        
        //音乐播放结束后继续播放此音乐，循环不停的播放
        audio.onEnded(() => {
          that.player(wx.getBackgroundAudioManager())
        })
      },
    onLoad: function(e) {this.player(wx.getBackgroundAudioManager())},
    bind_easymode_startup: function() {
        e.audioPlay(), n.newByMode(0) && this.goto_answer();
    },
    bind_hardmode_startup: function() {
        e.audioPlay(), n.newByMode(1) && this.goto_answer();
    },
    bind_code_startup: function(e, i) {
        n.newByCode(e, i) && this.goto_answer();
    },
    goto_answer: function() {
        wx.navigateTo({
            url: "/subpages/page3/riddle_answer/riddle_answer?vx=0"
        });
    },
    onShow: function () {
        //页面显示播放音乐
        this.player(wx.getBackgroundAudioManager())
      },
      onUnload: function() {
        //离开页面是停止播放音乐
        wx.getBackgroundAudioManager().stop();
      },
      onHide: function () {
        //离开页面是停止播放音乐
        wx.getBackgroundAudioManager().stop();
    
      },
});