// pages/answer/answer.js

var z = require("./../../utils/guiHelper.js")
var local_database = [{
      title: '在二战中，海军舰队主要舰种有航空母舰（CVA），重巡洋舰（CA），轻巡洋舰（CL），驱逐舰（DD）以及____组成',
      question:'在二战中，海军舰队主要舰种有航空母舰（CVA），重巡洋舰（CA），轻巡洋舰（CL），驱逐舰（DD）以及____组成"',
      option: ["战列舰（BB）","战列舰（AA）","战列舰（CC）","战列舰（DD）"],
      answer:"A",
  },
  {
    title: '在一战，海军设计了一类战舰，专为打击敌方巡洋舰而生，在面对战列舰也能以航速优势不据下风，该类战舰名为____',
      question:'在一战，海军设计了一类战舰，专为打击敌方巡洋舰而生，在面对战列舰也能以航速优势不据下风，该类战舰名为____',
      option: ["战列巡洋舰","战列舰","航母","巡洋舰"],
      answer:"A",
  },
  { 
    title: '抗日战争初期，中国海军以第1、第2舰队主力全灭为代价，在江上封锁线死守近三月，直至战役结束，日军始终未能达成循长江而上侧击淞沪前线的中国陆军侧翼的作战目的。以惨烈的牺牲拼死掩护了淞沪前线70万陆军，该战役名为____',
      question:'抗日战争初期，中国海军以第1、第2舰队主力全灭为代价，在江上封锁线死守近三月，直至战役结束，日军始终未能达成循长江而上侧击淞沪前线的中国陆军侧翼的作战目的。以惨烈的牺牲拼死掩护了淞沪前线70万陆军，该战役名为____',
      option: ["江阳海战","江阴海战","河阴海战","河阳海战"],
      answer:"B",
  },
  { 
    title: '二战结束，战列舰逐渐被更为强大的航母取代，世界上最后一艘建成的战列舰为法国的____',
      question:'二战结束，战列舰逐渐被更为强大的航母取代，世界上最后一艘建成的战列舰为法国的____',
      option: ["鞍山","密苏里","让巴尔","重庆"],
      answer:"c",
  },
  { 
    title: '在现实存在过的战列舰中，以炮管口径460㎜位居第一的是____',
      question:'在现实存在过的战列舰中，以炮管口径460㎜位居第一的是____',
      option: ["鞍山","密苏里","让巴尔","大和号战列舰"],
      answer:"D",
  },{
    
    title: '1953年苏联向中方出售四艘7型驱逐舰（愤怒级），四舰分别以"____" "抚顺" "长春" "太原"命名（太原舰1986年更名为青岛舰）。',
    question:'1953年苏联向中方出售四艘7型驱逐舰（愤怒级），四舰分别以"____" "抚顺" "长春" "太原"命名（太原舰1986年更名为青岛舰）。',
    option: ["鞍山","重庆","光荣","辽宁"],
    answer:"A",
},{ 
    title: '英国海军欧若拉轻巡洋舰作为赔偿移交中华民国政府，更名为____号巡洋舰，为迄今为止在中国人民解放军海军服役的唯一一艘轻巡洋舰。',
    question:'英国海军欧若拉轻巡洋舰作为赔偿移交中华民国政府，更名为____号巡洋舰，为迄今为止在中国人民解放军海军服役的唯一一艘轻巡洋舰。',
    option: ["重庆","鞍山","重庆","光荣"],
    answer:"A",
},
{ 
  title: '1945年9月2日，标志着二战结束的日本无条件投降的签字仪式，在停泊在东京湾的____号战列舰主甲板上举行',
    question:'1945年9月2日，标志着二战结束的日本无条件投降的签字仪式，在停泊在东京湾的____号战列舰主甲板上举行',
    option: ["大和","密苏里","重庆","让巴尔"],
    answer:"B",
},
{ 
  title: '1917年11月7日上午10时，列宁以革命军事委员会的名义起草了《告俄国公民书》，在“____”巡洋舰上的电台向全国广播。尔后，晚上9点45 分，"____”号按照信号，向冬宫发射了第一炮，揭开了伟大的十月社会主义革命的序幕。',
    question:'1917年11月7日上午10时，列宁以革命军事委员会的名义起草了《告俄国公民书》，在“____”巡洋舰上的电台向全国广播。尔后，晚上9点45 分，"____”号按照信号，向冬宫发射了第一炮，揭开了伟大的十月社会主义革命的序幕。',
    option: ["密苏里","让巴尔","光荣","阿芙乐尔"],
    answer:"D",
},
{ 
  title: '____是第一次世界大战中最大规模，以及史上参战战舰数量最庞大的海战，也是战争中交战双方唯一一次全面出动的舰队主力决战',
    question:'____是第一次世界大战中最大规模，以及史上参战战舰数量最庞大的海战，也是战争中交战双方唯一一次全面出动的舰队主力决战',
    option: ["莱特湾海战","对马海峡海战","日德兰海战","锡诺普海战"],
    answer:"C",
},
{ 
  title: '二战中美国海军获得“战斗之星”最多的战舰为____，共计20颗',
    question:'二战中美国海军获得“战斗之星”最多的战舰为____，共计20颗',
    option: ["企业号航母","华盛顿号航母","杜鲁门号航母","福特号航母"],
    answer:"A",
},
{ 
  title: '被称为二战太平洋战场转折点的战役是____',
    question:'被称为二战太平洋战场转折点的战役是____',
    option: ["日德兰海战","中途岛海战","莱特湾海战","对马海峡海战"],
    answer:"B",
},
{ 
  title: '1922至1936由于____的规定而造成各国海军大量裁军，大量战列舰和航空母舰建造计划被取消。该短时间也被称为海军假日',
    question:'1922至1936由于____的规定而造成各国海军大量裁军，大量战列舰和航空母舰建造计划被取消。该短时间也被称为海军假日',
    option: ["华盛顿海军条约","伦敦海军条约","关岛海军条约","第二次伦敦海军条约"],
    answer:"A",
},
{ 
  title: '在中途岛海战中，企业号与同级大黄蜂号、约克城号埋伏在中途岛东北海域，一举击沉日本海军机动部队的____艘航空母舰',
    question:'在中途岛海战中，企业号与同级大黄蜂号、约克城号埋伏在中途岛东北海域，一举击沉日本海军机动部队的____艘航空母舰',
    option: ["1","2","3","4"],
    answer:"D",
},
{ 
  title: '第一次世界大战结束前德意志帝国海军下属的水面作战舰队名为____。',
    question:'第一次世界大战结束前德意志帝国海军下属的水面作战舰队名为____。',
    option: ["太平洋舰队","北海舰队","黑海舰队","公海舰队"],
    answer:"D",
},
{ 
  title: '自日德兰海战后德国在第一次世界大战中不再以海军与协约国正面交锋，而是采用以潜艇攻击舰艇和破坏敌军补给线的方式，该策略被称为____。',
    question:'自日德兰海战后德国在第一次世界大战中不再以海军与协约国正面交锋，而是采用以潜艇攻击舰艇和破坏敌军补给线的方式，该策略被称为____。',
    option: ["破交作战","海上进攻战","攻势布雷","反潜战斗"],
    answer:"A",
},
{ 
  title: '在二战的____战役航空母舰舰载机问世以来首次大规模袭击港内舰艇，突出显示了航载航空兵的巨大突击威力，震惊了整个世界。',
    question:'在二战的____战役航空母舰舰载机问世以来首次大规模袭击港内舰艇，突出显示了航载航空兵的巨大突击威力，震惊了整个世界。',
    option: ["地中海","塔兰托","莱特湾","瓜岛"],
    answer:"B",
},
{ 
  title: '作为二战太平洋战场的开端，同时是美国参战的导火索是____',
    question:'作为二战太平洋战场的开端，同时是美国参战的导火索是____',
    option: ["空袭华盛顿","空袭芝加哥","空袭珍珠港","空袭好莱坞"],
    answer:"C",
},
{ 
  title: '____被称为“舰历最短的军舰”——竣工后10日，首次出航后17时被美国潜艇击沉',
    question:'____被称为“舰历最短的军舰”——竣工后10日，首次出航后17时被美国潜艇击沉',
    option: ["丛云","雾岛","能代","信浓"],
    answer:"D",
},{ 
    title: '航速单位的节是指：____',
      question:'航速单位的节是指：____',
      option: ["1公里/小时","1英里/小时","1海里/分钟","1海里/小时"],
      answer:"D",
  },{ 
    title: '舰艇上操控军舰和指挥作战的地方称为：____',
      question:'舰艇上操控军舰和指挥作战的地方称为：____',
      option: ["机舱","舰桥","指挥室","驾驶室"],
      answer:"B",
  },{ 
    title: '在航空母舰上起降的飞机一般被称为____',
      question:'在航空母舰上起降的飞机一般被称为____',
      option: ["舰载机","轰炸机","鱼雷机","战斗机"],
      answer:"A",
  },{ 
    title: '舰艇为保持或恢复自身生命力所采取的预防，限制或消除损害的措施被称为____',
      question:'舰艇为保持或恢复自身生命力所采取的预防，限制或消除损害的措施被称为____',
      option: ["损害控制","损害管控","损害管制","损伤管制"],
      answer:"C",
  },{ 
    title: '历史上潜艇装备过最大口径的舰炮为____口径',
      question:'历史上潜艇装备过最大口径的舰炮为____口径',
      option: ["305mm","355mm","295mm","210mm"],
      answer:"A",
  },{ 
    title: '舰桥与轮机舱之间发出与接收舰艇前进与倒退指令的设备叫____',
      question:'舰桥与轮机舱之间发出与接收舰艇前进与倒退指令的设备叫____',
      option: ["钟","车钟","挡位","轮机"],
      answer:"B",
  },{ 
    title: '世界上第一艘专门建造的航空母舰在____年建成服役',
      question:'世界上第一艘专门建造的航空母舰在____年建成服役',
      option: ["1922","1912","1923","1920"],
      answer:"A",
  },{ 
    title: '炮弹进入水中继续前进而击中水下装甲的现象被称为____',
      question:'炮弹进入水中继续前进而击中水下装甲的现象被称为____',
      option: ["水弹","中弹","穿透弹","水中弹"],
      answer:"D",
  },{ 
    title: '炮弹击中装甲由于角度过大导致弹开，未能击穿护甲的现象被称为____',
      question:'炮弹击中装甲由于角度过大导致弹开，未能击穿护甲的现象被称为____',
      option: ["弹弹","流弹","跳弹","空弹"],
      answer:"C",
  },{ 
    title: '为了缩短飞机起飞距离，航母在飞机起飞时应该____',
      question:'为了缩短飞机起飞距离，航母在飞机起飞时应该____',
      option: ["顺风航行","逆风航行","垂直风向航行","停止航行"],
      answer:"B",
  },{ 
    title: 'VT引信又被称为____',
      question:'VT引信又被称为____',
      option: ["无线电近炸引信","无线电远炸引信","近炸引信","无线电引信"],
      answer:"A",
  },{ 
    title: '海军常用单位“链”是____单位',
      question:'海军常用单位“链”是____单位',
      option: ["时间","数量","体积","长度"],
      answer:"D",
  },{ 
    title: '轻巡和重巡口径划分是____英寸',
      question:'轻巡和重巡口径划分是____英寸',
      option: ["6.6","6.4","6.1","5.8"],
      answer:"C",
  },{ 
    title: '舰和艇的常用划分标准是____',
      question:'舰和艇的常用划分标准是____',
      option: ["长度","吨位","体积","速度"],
      answer:"B",
  },{ 
    title: '二战时期美军对日本本土实施的首次空袭是____',
      question:'二战时期美军对日本本土实施的首次空袭是____',
      option: ["杜立特空袭","格尔尼卡空袭","拉包尔空战","“大礼拜”空袭"],
      answer:"A",
  },{ 
    title: '二战德国最大战舰俾斯麦号唯一一次任务为____，旨在突破英国封锁进入大西洋执行破交',
      question:'二战德国最大战舰俾斯麦号唯一一次任务为____，旨在突破英国封锁进入大西洋执行破交',
      option: ["春风行动","莱茵演习行动","击鼓行动","霹雳行动"],
      answer:"B",
  },{ 
    title: '英国海军____号为历史上唯一一艘被战列舰击沉的航母',
      question:'英国海军____号为历史上唯一一艘被战列舰击沉的航母',
      option: ["丛云","雾岛","光荣","信浓"],
      answer:"C",
  },
]
Page({

  /**
   * 页面的初始数据
   */
  data: {
      sumbg:"",
    showSummary: !1,
      select: "",
      status: "",
      list: local_database,
      index: 0,
      answerNow: 0,
      optionList: ["A", "B", "C", "D"],
      successNum: 0,
      failNum: 0,
      defen: 0,
      ny: true,
  },
  player(audio) {
    var that = this
    //title不写或放空会报错哦，即使不报错ios系统会不播放，所以必须加
    audio.title = 'exam'
 
    //这点需知微信小程序上线不能超过2M,音乐文件会很大，所以要放在服务器上才可以
    audio.src = 'https://636c-cloud1-0gyoose47fbc4007-1324810507.tcb.qcloud.la/images7/%E7%AD%94%E9%A2%98.mp3?sign=ebacb00b531bbabe27d36163db1f6074&t=1710754310'
    
    //音乐播放结束后继续播放此音乐，循环不停的播放
    audio.onEnded(() => {
      that.player(wx.getBackgroundAudioManager())
    })
  },
  getnumber: function(e) {
      var code=[{title: '',
      question:'',
      option: ["A", "B", "C", "D"],
      answer:'',},{title: '',
      question:'',
      option: ["A", "B", "C", "D"],
      answer:'',},{title: '',
      question:'',
      option:["A", "B", "C", "D"],
      answer:'',},{title: '',
      question:'',
      option: ["A", "B", "C", "D"],
      answer:'',},{title: '',
      question:'',
      option: ["A", "B", "C", "D"],
      answer:'',}];
      var c=[];
      let numbers = [];
            while (numbers.length < 5) {
              const num = Math.floor(Math.random() * 35).toFixed(0);
              if (numbers.indexOf(num) === -1) {
                numbers.push(num);
              }
            }
    for (let i = 0; i < 5; i++) {
        var id = numbers[i]

        code[i].answer=this.data.list[id].answer,code[i].title=this.data.list[id].title,
        code[i].question=this.data.list[id].question,code[i].option=this.data.list[id].option;
    }
    this.setData({code})
  },
  nextQuestion (e) { 
    z.audioPlay()
    const { item } = e.currentTarget.dataset;
    if (this.data.answerNow < this.data.code.length-1 ) {//不是最后一题
        this.setData({
            select: item,
            status: "success",
            failNum: this.data.failNum + 1,
            ny: false,
        });
        setTimeout(() => {
            this.setData({
                answerNow: this.data.answerNow + 1,
                status: "",
                select: "",
                ny: true,
            })
        }, 1500);
    }
    else{
        this.setData({
            select: item,
            status: "success",
            failNum: this.data.failNum + 1,
            ny: false,
        });
        this.showAchievement({},1500);
    }
  },
  selectAnswer(e) {
      const { item } = e.currentTarget.dataset;
      // 1. 用户选择的是什么选项
      // 2. 这个选项是错误还是正确
      // 3. 给用户提示, 进行背景颜色的替换
      // 4. 跳转到下一个题目
      const answer = this.data.code[this.data.answerNow].answer;
      if (item === answer) {
          // 正确
          z.audioPlay(2)
          this.setData({
          defen: this.data.defen + 20
        })
          this.setData({
              select: item,
              status: "success",
              successNum: this.data.successNum + 1,
          })
      } else {
          // 错误
          z.audioPlay(3)
          this.setData({
              select: item,
              status: "fail",
              failNum: this.data.failNum + 1,
              ny: false,
          });
          setTimeout(() => {
            this.setData({
                status: "",
                select: "",
                ny: true,
            })
        }, 1500);
      }

      if (this.data.answerNow === this.data.code.length - 1) {
        z.audioPlay(4)
          this.showAchievement({},1500);
      } else {
          setTimeout(() => {
              this.setData({
                  answerNow: this.data.answerNow + 1,
                  status: "",
                  select: "",
              })
          }, 1500);
      }
  },
  showAchievement: function() {
        var u = 0;
        var c = this.defen;
        if (100 == c) u = 1; else if (c > 80) u = 2 ; else if (c <= 80 && c > 60) u = 3; else if (c <= 60 && c > 0) {
            u = 4;
        } else u = 5;
        this.setData({ 
            sumBg : "cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images7/弹窗" + u + ".png",
            showSummary : !0,})
},
bind_onemoregame: function() {
    this.setData({code:[{title: '',
    question:'',
    option: '',
    answer:'',},{title: '',
    question:'',
    option: '',
    answer:'',},{title: '',
    question:'',
    option: '',
    answer:'',},{title: '',
    question:'',
    option: '',
    answer:'',},{title: '',
    question:'',
    option: '',
    answer:'',}]})
    z.audioPlay()
    wx.reLaunch({
        url: "/subpages/page7/examstart/examstart"
    });
},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    this.player(wx.getBackgroundAudioManager())
    this.getnumber();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.player(wx.getBackgroundAudioManager())
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
    wx.getBackgroundAudioManager().stop();
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    wx.getBackgroundAudioManager().stop();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})