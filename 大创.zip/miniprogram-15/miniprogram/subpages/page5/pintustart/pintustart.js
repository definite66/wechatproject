var e = require("./../../utils/guiHelper.js"), n = require("./../../utils/questionHandler.js");
getApp();

Page({
    data: {},
    player(audio) {
        var that = this
        //title不写或放空会报错哦，即使不报错ios系统会不播放，所以必须加
        audio.title = 'LLK'
        //这点需知微信小程序上线不能超过2M,音乐文件会很大，所以要放在服务器上才可以
        audio.src = 'https://636c-cloud1-0gyoose47fbc4007-1324810507.tcb.qcloud.la/images/%E8%BF%9E%E8%BF%9E%E7%9C%8B%E3%80%81%E7%BF%BB%E7%89%8C%E3%80%81%E6%8B%BC%E5%9B%BE.mp3?sign=47a5dccc9cb31c75d56395ff1a96fcd4&t=1710755152'
        
        //音乐播放结束后继续播放此音乐，循环不停的播放
        audio.onEnded(() => {
          that.player(wx.getBackgroundAudioManager())
        })
      },
    onLoad: function(e) {this.player(wx.getBackgroundAudioManager())},
    bind_hardmode_startup: function() {
        e.audioPlay(), n.newByMode(1) && this.goto_answer();
    },
    goto_answer: function() {
        wx.navigateTo({
            url: "/subpages/page5/imagepintu/imagepintu"
        });
    },
    onShow: function () {
        //页面显示播放音乐
        this.player(wx.getBackgroundAudioManager())
      },
      onUnload: function() {
        //离开页面是停止播放音乐
        wx.getBackgroundAudioManager().stop();
      },
      onHide: function () {
        //离开页面是停止播放音乐
        wx.getBackgroundAudioManager().stop();
    
      },
});