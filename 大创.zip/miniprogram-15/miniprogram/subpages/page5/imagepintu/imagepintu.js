// pages/imagepintu/imagepintu.js
var b = require("./../../utils/guiHelper.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sumbg:"",
    showSummary: !1,
    number:1,
    useTime: 0,
      timer: '',
      clickable: false
  },
  player(audio) {
    var that = this
    //title不写或放空会报错哦，即使不报错ios系统会不播放，所以必须加
    audio.title = 'LLK'
    //这点需知微信小程序上线不能超过2M,音乐文件会很大，所以要放在服务器上才可以
    audio.src = 'https://636c-cloud1-0gyoose47fbc4007-1324810507.tcb.qcloud.la/images/%E8%BF%9E%E8%BF%9E%E7%9C%8B%E3%80%81%E7%BF%BB%E7%89%8C%E3%80%81%E6%8B%BC%E5%9B%BE.mp3?sign=47a5dccc9cb31c75d56395ff1a96fcd4&t=1710755152'
    
    //音乐播放结束后继续播放此音乐，循环不停的播放
    audio.onEnded(() => {
      that.player(wx.getBackgroundAudioManager())
    })
  },
  startGame: function () {
    var data = this.data; 
    var that = this;
    this.setData({
      useTime: 0,
      timer: '',
      clickable: false
    }); // 开始游戏
    var that = this;
    setTimeout(function () {
      data.clickable = true; // 开始计时了才让点
      if (data.timer === '') {
        data.timer = setInterval(function () {
          data.useTime++;
          that.setData({
             useTime: data.useTime 
          });
        }, 1000); // 游戏开始计时
      } else {
        that.setData({ useTime: 0 });
      }
    }, 1000); // 游戏开始前先让玩家记忆1秒钟
  },
  //游戏初始化：
  //初始化的时候，这里用了sortArr(arr)打乱数组，并拼接个空白格[9]，这样让空白格初始化的时候永远处于最后一位。
  init: function () {
    this.setData({
      num: this.sortArr([1, 2, 3, 4, 5, 6, 7, 8]).concat([9])
    })
  },
  //随机打乱数组:
  sortArr: function (arr) {
    return arr.sort(function () {
      return Math.random() - 0.5
    })
  },
  //给每个块添加点击事件onMoveTap:
  onMoveTap: function (e) {
    b.audioPlay(0)
    var index = e.currentTarget.dataset.index; //当前数字下标
    console.log(index);
    var item = e.currentTarget.dataset.item;
    if (this.data.num[index + 3] == 9) {
      this.move(index, index + 3); //this.down(e);
    }
    if (this.data.num[index - 3] == 9) {
      this.move(index, index - 3); //this.up(e);
    }
    if (this.data.num[index + 1] == 9 && index != 2 && index != 5) {
      this.move(index, index + 1); //this.right(e);
    }
    if (this.data.num[index - 1] == 9 && index != 3 & index != 6) {
      this.move(index, index - 1); //this.left(e);
    }
  },
  //以向上移动举例
  move: function (index1, index2) {
    //var index = e.currentTarget.dataset.index; //当前数字下标
    var temp = this.data.num[index1];
    this.data.num[index1] = this.data.num[index2]
    this.data.num[index2] = temp;
    this.setData({
      num: this.data.num
    })
    //这里把数组转化成字符串做的比较
    if (this.data.num.toString() == [1, 2, 3, 4, 5, 6, 7, 8, 9].toString()) {
      this.success();
    }
  },
  //以向上移动举例
  up: function (e) {
    var index = e.currentTarget.dataset.index; //当前数字下标
    var temp = this.data.num[index];
    this.data.num[index] = this.data.num[index - 3]
    this.data.num[index - 3] = temp;
    this.setData({
      num: this.data.num
    })
    //这里把数组转化成字符串做的比较
    if (this.data.num.toString() == [1, 2, 3, 4, 5, 6, 7, 8, 9].toString()) {
      this.success();
    }
  },
  //游戏成功：
  success: function () {S
    b.audioPlay(4)
    this.showAchievement();
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.player(wx.getBackgroundAudioManager())
    this.init();
    this.startGame();
    var i = (Math.random() * 2 + 1).toFixed(0);
    this.setData({
    number:i,
})
  },
  showAchievement: function() {
    var u = 0;
    var c = this.defen;
    if (c <= 30) u = 1; else if (c <= 50&& c > 30) u = 2 ; else if (c <= 80 && c > 50) u = 3; else if (c <= 120 && c > 80) {
      u = 4;
  } else u = 5;
    this.setData({ 
        sumBg : "cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images5/" + u + ".png",
        showSummary : !0,})
},
bind_onemoregame: function() {
  b.audioPlay(0)
wx.reLaunch({
    url: "/subpages/page5/pintustart/pintustart"
});
},
onShow: function () {
  //页面显示播放音乐
  this.player(wx.getBackgroundAudioManager())
},
onUnload: function() {
  //离开页面是停止播放音乐
  wx.getBackgroundAudioManager().stop();
},
onHide: function () {
  //离开页面是停止播放音乐
  wx.getBackgroundAudioManager().stop();

},


})