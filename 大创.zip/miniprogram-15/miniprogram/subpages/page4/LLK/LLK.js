// pages/LLK/LLK.js

var xs;
    wx.getSystemInfo({
      success: function(res) {
        xs = res.windowWidth/375;
      },
    })
var b = require("./../../utils/guiHelper.js")
var map = [];
var Select_first = false; //是否已经选中第一块
var linePointStack = []; //存储连接的折点棋盘坐标
var Height = 10;
var Width = 8;
var p1, p2; //存储选中第一块，第二块方块对象坐标
//定义坐标点类
function Point(_x, _y) {
  this.x = _x;
  this.y = _y;
}

function randomsort(a, b) {
  return Math.random() > .5 ? -1 : 1;
  //用Math.random()函数生成0~1之间的随机数与0.5比较，返回-1或1
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sumbg:"",
    showSummary: !1,
    useTime: 0,
    timer: '',
    clickable: false,
  },
  player(audio) {
    var that = this
    //title不写或放空会报错哦，即使不报错ios系统会不播放，所以必须加
    audio.title = 'LLK'
    //这点需知微信小程序上线不能超过2M,音乐文件会很大，所以要放在服务器上才可以
    audio.src = 'https://636c-cloud1-0gyoose47fbc4007-1324810507.tcb.qcloud.la/images/%E8%BF%9E%E8%BF%9E%E7%9C%8B%E3%80%81%E7%BF%BB%E7%89%8C%E3%80%81%E6%8B%BC%E5%9B%BE.mp3?sign=47a5dccc9cb31c75d56395ff1a96fcd4&t=1710755152'
    
    //音乐播放结束后继续播放此音乐，循环不停的播放
    audio.onEnded(() => {
      that.player(wx.getBackgroundAudioManager())
    })
  },
  /**
   *判断选中的两个方块是否可以消除
   */
  startGame: function () {
    var data = this.data; 
    var that = this;
    this.setData({
      useTime: 0,
      timer: '',
      clickable: false
    }); // 开始游戏
    var that = this;
    setTimeout(function () {
      data.clickable = true; // 开始计时了才让点
      if (data.timer === '') {
        data.timer = setInterval(function () {
          data.useTime++;
          that.setData({
             useTime: data.useTime 
          });
        }, 1000); // 游戏开始计时
      } else {
        that.setData({ useTime: 0 });
      }
    }, 1000); // 游戏开始前先让玩家记忆1秒钟
  },// 游戏开始前先让玩家记忆1秒钟
  IsLink: function(p1, p2) {
    if (this.lineCheck(p1, p2)) //直接连通
      return true;
    if (this.OneCornerLink(p1, p2)) // 一个转弯（折点）的联通方式
      return true;
    if (this.TwoCornerLink(p1, p2)) // 两个转弯（折点）的联通方式
      return true;
    return false;
  },

  /**
   *
   * x代表列，y代表行
   * param p1 第一个保存上次选中点坐标的点对象
   * param p2 第二个保存上次选中点坐标的点对象
   */
  //直接连通
  lineCheck: function(p1, p2) {
    var absDistance = 0;
    var spaceCount = 0;
    var zf;
    console.log(p1.x + "," + p1.y + " ; " + p2.x + "," + p2.y);
    if (p1.x == p2.x || p1.y == p2.y) //  同行同列的情况吗？
    {
      //同列的情况
      if (p1.x == p2.x && p1.y != p2.y) {
        console.log(" 同列的情况！！");
        console.log(p1.x + "," + p2.x);
        // 绝对距离(中间隔着的空格数)
        absDistance = Math.abs(p1.y - p2.y) - 1;
        //正负值
        if (p1.y - p2.y > 0)
          zf = -1;
        else
          zf = 1;
        for (var i = 1; i < absDistance + 1; i++) {
          if (map[p1.x][p1.y + i * zf] == " ")
            //空格数加1
            spaceCount += 1;
          else
            break; //遇到阻碍就不用再探测了
        }
      } else if (p1.y == p2.y && p1.x != p2.x) { //同行的情况      
        console.log(" 同行的情况！！");
        console.log(p1.x + "," + p2.x);
        console.log(p1.y + "," + p2.y);
        absDistance = Math.abs(p1.x - p2.x) - 1
        //正负值
        if (p1.x - p2.x > 0)
          zf = -1;
        else
          zf = 1;
        for (var i = 1; i < absDistance + 1; i++) {
          if (map[p1.x + i * zf][p1.y] == " ")
            // 空格数加1
            spaceCount += 1;
          else
            break; //遇到阻碍就不用再探测了
        }
      }
      console.log("距离" + spaceCount + "," + absDistance);
      if (spaceCount == absDistance) {
        //可联通          
        console.log("行/列可直接联通");
        return true;
      } else {
        console.log("行/列不能消除！");
        return false;
      }
    } else //不是同行同列的情况所以直接返回false
      return false;
  },

  /**
   *第二种，一个折点连通（直角连通）  
   *一个折点连通
   *@param first: 选中的第一个点
   *@param second: 选中的第二个点
   */
  OneCornerLink: function(p1, p2) {
    //第一个直角检查点
    var checkP = new Point(p1.x, p2.y);
    //第二个直角检查点
    var checkP2 = new Point(p2.x, p1.y);
    //第一个直角点检测
    if (map[checkP.x][checkP.y] == " ")
      if (this.lineCheck(p1, checkP) && this.lineCheck(checkP, p2)) {
        linePointStack.push(checkP);
        console.log("直角消除ok", checkP.x, checkP.y);
        return true;
      }
    //第二个直角点检测
    if (map[checkP2.x][checkP2.y] == " ")
      if (this.lineCheck(p1, checkP2) && this.lineCheck(checkP2, p2)) {
        linePointStack.push(checkP2);
        console.log("直角消除ok", checkP2.x, checkP2.y);
        return true;
      }
    console.log("不能直角消除");
    return false;
  },

  /**
   *第三种，两个折点连通（双直角连通）
   *@param p1 第一个点
   *@param p2 第二个点
   */
  TwoCornerLink: function(p1, p2) {
    var checkP = new Point(p1.x, p1.y);
    //四向探测开始
    for (var i = 0; i < 4; i++) {
      checkP.x = p1.x;
      checkP.y = p1.y;
      //向下
      if (i == 3) {
        checkP.y += 1;
        while ((checkP.y < Height) && map[checkP.x][checkP.y] == " ") {
          linePointStack.push(checkP);
          if (this.OneCornerLink(checkP, p2)) {
            console.log("下探测OK");
            return true;
          } else
            linePointStack.pop();
          checkP.y += 1
        }
      } else if (i == 2) { // 向右
        checkP.x += 1;
        while ((checkP.x < Width) && map[checkP.x][checkP.y] == " ") {
          linePointStack.push(checkP)
          if (this.OneCornerLink(checkP, p2)) {
            console.log("右探测OK");
            return true;
          } else
            linePointStack.pop();
          checkP.x += 1;
        }
      }
      // 向左
      else if (i == 1) {
        checkP.x -= 1;
        while ((checkP.x >= 0) && map[checkP.x][checkP.y] == " ") {
          linePointStack.push(checkP);
          if (this.OneCornerLink(checkP, p2)) {
            console.log("左探测OK");
            return true;
          } else
            linePointStack.pop();
          checkP.x -= 1;
        }
      }
      //向上
      else if (i == 0) {
        checkP.y -= 1;
        while ((checkP.y >= 0) && map[checkP.x][checkP.y] == " ") {
          linePointStack.push(checkP);
          if (this.OneCornerLink(checkP, p2)) {
            console.log("上探测OK");
            return true;
          } else
            linePointStack.pop();
          checkP.y -= 1;
        }
      }
    }
    //四个方向都寻完都没找到适合的checkP点
    console.log("两直角连接没找到适合的checkP点")
    return false;

  },
  //事件处理函数
  /**
   * 自动查找出一组相同可以抵消的方块功能封装在Find2Block（）
   */
  find2Block: function() {
    //自动查找
    b.audioPlay(1)
    var m_nRoW = Height;
    var m_nCol = Width;
    var bFound = false;
    var x1, y1, x2, y2;
    //第一个方块从地图的0位置开始
    for (var i = 0; i < m_nRoW * m_nCol; i++) {
      //找到则跳出循环
      if (bFound)
        break;
      //算出对应的虚拟行列位置
      x1 = i % m_nCol;
      y1 = Math.floor(i / m_nCol); //整除
      console.log("aaa" + y1);
      p1 = new Point(x1, y1);
      //无图案的方块跳过
      if (map[x1][y1] == ' ')
        continue
      //第二个方块从前一个方块的后面开始
      for (var j = i + 1; j < m_nRoW * m_nCol; j++) {
        //算出对应的虚拟行列位置
        x2 = j % m_nCol;
        y2 = Math.floor(j / m_nCol); //整除             
        p2 = new Point(x2, y2);
        // 第二个方块不为空 且与第一个方块的图标相同
        if (map[x2][y2] != ' ' && this.IsSame(p1, p2)) {
          //判断是否可以连通
          if (this.IsLink(p1, p2)) {
            bFound = true;
            break;
          }
        }
      }
    }
    //找到后
    if (bFound) { //p1（x1,y1）与p2（x2,y2）连通
      console.log('找到后');
      let ctx = this.ctx;
      this.print_map();
      //画选定（x1,y1)处的框线
      ctx.strokeRect(p1.x * 40*xs, p1.y * 40*xs, 40*xs, 40*xs);
      //画选定（x2,y2)处的框线
      ctx.strokeRect(p2.x * 40*xs, p2.y * 40*xs, 40*xs, 40*xs);
      ctx.draw();
    } else {
      console.log('没找到');
    }
    return bFound;
  },
  /**
   *按地图map中记录图案信息将图标图案显示在Canvas对象中，生成游戏开始的界面。
   */
  print_map: function() { //输出map地图
    let ctx = this.ctx
    for (var x = 0; x < Width; x++)
      for (var y = 0; y < Height; y++)
        if (map[x][y] != ' ') {
          var img1 = '/subpages/page4/LLK/images/' + map[x][y] + ".png"; //例如'/images/4.jpg'
          //ctx.drawImage('/images/4.png', 50 * i, 50, 50, 50)
          ctx.drawImage(img1, 40*xs * x, 40*xs * y, 40*xs, 40*xs);
          //id = cv.create_image((x * 25 + 20, y * 25 + 20), image = img1)
          //image_map[x][y] = id;
        }
    for (var x = 0; x < Width; x++)
      for (var y = 0; y < Height; y++) {
        //console.log(map[x][y]);
      }
  },
  touchStart: function(e) {
    b.audioPlay(1)
    var x = Math.floor(e.touches[0].x / 40*xs);
    var y = Math.floor(e.touches[0].y / 40*xs);
    var pair=false;
    let ctx = this.ctx;
    this.print_map(); //输出map地图
    /*this.setData({
      startx: startx,
      starty: starty
    })
    */
    console.log("clicked at" + x + "，" + y);
    //console.log(y);
    if (map[x][y] == " ")
      console.log("提示此处无方块");
    else {
      if (Select_first == false) {
        p1 = new Point(x, y);
        //画选定（x1,y1)处的框线
        ctx.setStrokeStyle("red");
        ctx.strokeRect(x * 40*xs, y * 40*xs, 40*xs, 40*xs);
        Select_first = true;
      } else {
        p2 = new Point(x, y);
        //判断第二次点击的方块是否已被第一次点击选取，如果是则返回。
        if ((p1.x == p2.x) && (p1.y == p2.y))
          return;
        //画选定（x2,y2)处的框线
        console.log('第二次点击的方块' + x + ', ' + y)
        ctx.strokeRect(x * 40*xs, y * 40*xs, 40*xs, 40*xs);
        if (this.IsSame(p1, p2) && this.IsLink(p1, p2)) { //判断是否连通
          console.log('连通' + x + ', ' + y);
          Select_first = false;
          //画选中方块之间连接线 
          this.drawLinkLine(p1, p2);
          map[p1.x][p1.y] = ' ';
          map[p2.x][p2.y] = ' ';
          linePointStack = [];
          pair=true;   //配对成功
b.audioPlay(2)
          if (this.isWin()) { //游戏结束
            b.audioPlay(4)
          }
        } else { //不能连通则取消选定的2个方块  
          //cv.delete(firstSelectRectId) 			#清除第一个选定框线
          //cv.delete(SecondSelectRectId) 		#清除第2个选定框线
          Select_first = false;
          b.audioPlay(3)
        }
      }
    }
    ctx.draw();
    if (pair)
    {
      this.print_map(); //输出map地图
      setTimeout(function () {        
        ctx.draw();
        //console.log(pair)
        //console.log("配对成功")
        //return;
      }, 500); //过半秒
    }
         

  },

  drawLinkLine: function(p1, p2) { //画连接线
    console.log("折点数" + linePointStack.length);
    if (linePointStack.length == 0) //直线联通
      this.drawLine(p1, p2);
    if (linePointStack.length == 1) { //一折连通
      var z = linePointStack.pop();
      console.log("一折连通点z" + z.x + z.y);
      this.drawLine(p1, z);
      this.drawLine(p2, z);
    }
    if (linePointStack.length == 2) { //2折连通
      var z1 = linePointStack.pop()
      //print("2折连通点z1",z1.x,z1.y)
      this.drawLine(p2, z1)
      var z2 = linePointStack.pop()
      //print("2折连通点z2",z2.x,z2.y)
      this.drawLine(z1, z2);
      this.drawLine(p1, z2);
    }
  },

  //绘制(p1, p2)之间的直线
  drawLine: function(p1, p2) {
    let ctx = this.ctx;
    ctx.beginPath();
    ctx.moveTo(p1.x * 40*xs + 20*xs, p1.y * 40*xs + 20*xs);
    ctx.lineTo(p2.x * 40*xs + 20*xs, p2.y * 40*xs + 20*xs);
    //print("drawLine p1,p2",p1.x,p1.y,p2.x,p2.y)
    //ctx.create_line(p1.x * 40 + 20, p1.y * 40 + 20, p2.x * 40 + 20, p2.y * 40 + 20);
    ctx.stroke();
  },

  /**
   *IsSame(p1,p2)判断p1 ( x1, y1)与p2(x2, y2)处的方块图案是否相同。
   */
  IsSame: function(p1, p2) {
    if (map[p1.x][p1.y] == map[p2.x][p2.y]) {
      console.log("clicked at IsSame");
      return true;
    }
    return false;
  },
  /**
   *#检测是否已经赢得了游戏
   */
  isWin: function() {
    //检测是否尚有非未被消除的方块
    //(非BLANK_STATE状态)
    for (var y = 0; y < Height; y++)
      for (var x = 0; x < Width; x++)
        if (map[x][y] != " ")
          return false;
    this.showAchievement();      
    return true;
  },

  init: function() {
    //初始化地图, 将地图中所有方块区域位置置为空方块状态
    for (var x = 0; x < Width; x++) {
      map[x] = new Array();
      for (var y = 0; y < Height; y++) {
        map[x][y] = " "; //" "表示空的
      }
    }
  },
  create_map: function() { //生成随机地图
    //生成随机地图
    //将所有匹配成对的图标索引号放进一个临时的地图中
    var tmpMap = [];
    var m = (Width) * (Height) / 10;
    for (var x = 1; x <= m; x++)
      for (var i = 0; i < 10; i++) // 每种方块有10个
        tmpMap.push(x);
    tmpMap.sort(randomsort);
    //random.shuffle(tmpMap) //生成随机地图
    for (var x = 0; x < Width; x++) {
      for (var y = 0; y < Height; y++)
        map[x][y] = tmpMap[x * Height + y]; //从上面的临时地图中获取
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.player(wx.getBackgroundAudioManager())
    //创建画布上下文
    this.ctx = wx.createCanvasContext('myCanvas')
    this.startGame();
    this.init(); //初始化地图, 将地图中所有方块区域位置置为空方块状态
    this.create_map() ; //生成随机地图
    this.print_map(); //输出map地图
    this.ctx.draw();
  },
  showAchievement: function() {
    var u = 0;
    var c = this.useTime;
    if (c <= 30) u = 1; else if (c <= 50&& c > 30) u = 2 ; else if (c <= 80 && c > 50) u = 3; else if (c <= 120 && c > 80) {
        u = 4;
    } else u = 5;
    this.setData({ 
      sumBg : "cloud://cloud1-0gyoose47fbc4007.636c-cloud1-0gyoose47fbc4007-1324810507/images5/" + u + ".png",
        showSummary : !0,})
},
bind_onemoregame: function() {
  b.audioPlay()
wx.reLaunch({
    url: "/subpages/page4/LLKstart/LLKstart"
});
},
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.player(wx.getBackgroundAudioManager())
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    wx.getBackgroundAudioManager().stop();
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    wx.getBackgroundAudioManager().stop();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})