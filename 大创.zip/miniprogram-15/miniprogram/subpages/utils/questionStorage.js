var s = require("./common.js"), e = require("./consts.js"), a = [ {
    code: "MY000001",
    puzzle: "航速单位的节是指：1()每小时",
    ans_scope: "打二字",
    ans_prompt: "**",
    ans_result: "海里",
    ans_analyze: "海*",
    difficulty: "1",
    choose: "海未入才里香沈网圭智来套"
}, {
    code: "MY000002",
    puzzle: "舰艇上操控军舰和指挥作战的地方称为：（）",
    ans_scope: "打二字",
    ans_prompt: "**",
    ans_result: "舰桥",
    ans_analyze: "*桥",
    difficulty: "1",
    choose: "卡拾舰息忘金以妻圭桥兄把"
}, {
    code: "MY000003",
    puzzle: "炮弹进入水中继续前进而击中水下装甲的现象被称为（）",
    ans_scope: "打三字",
    ans_prompt: "***",
    ans_result: "水中弹",
    ans_analyze: "水*弹",
    difficulty: "1",
    choose: "罗洛水中弹甘味哀及皂上镜"
}, {
    code: "MY000004",
    puzzle: "为了缩短飞机起飞距离，航母在飞机起飞时应该（）航行",
    ans_scope: "打二字",
    ans_prompt: "***",
    ans_result: "逆风",
    ans_analyze: "*风",
    difficulty: "1",
    choose: "几念逆风根戏未一新沉质原"
}, {
    code: "MY000005",
    puzzle: "在航空母舰上起降的飞机一般被称为（）",
    ans_scope: "打三字",
    ans_prompt: "舰**",
    ans_result: "舰载机",
    ans_analyze: "**机",
    difficulty: "1",
    choose: "载林舰成归都软弹机许两病"
}, {
    code: "MY000006",
    puzzle: "舰桥与轮机舱之间发出与接收舰艇前进与倒退指令的设备叫（）",
    ans_scope: "打二字",
    ans_prompt: "**",
    ans_result: "车钟",
    ans_analyze: "*钟",
    difficulty: "1",
    choose: "钟患新李车盛婆欲目能死留"
}, {
    code: "MY000007",
    puzzle: "二战时期美军对日本本土实施的首次空袭是（）空袭",
    ans_scope: "打三字",
    ans_prompt: "***",
    ans_result: "杜立特",
    ans_analyze: "杜**",
    difficulty: "1",
    choose: "雷特杜枝树饭也珍立疏天合"
}, {
    code: "MY000008",
    puzzle: "英国海军（）号为历史上唯一一艘被战列舰击沉的航母",
    ans_scope: "打二字",
    ans_prompt: "**",
    ans_result: "光荣",
    ans_analyze: "*荣",
    difficulty: "1",
    choose: "女衍镝光有锅卡荣戏不空鸯"
}, {
    code: "MY000009",
    puzzle: "炮弹击中装甲由于角度过大导致弹开，未能击穿护甲的现象被称为（）",
    ans_scope: "打二字",
    ans_prompt: "**",
    ans_result: "跳弹",
    ans_analyze: "跳*",
    difficulty: "1",
    choose: "也经跳减许迎鸟笋峰弹饭居"
}, {
    code: "MY000010",
    puzzle: "被称为二战太平洋战场转折点的是（）海战一役",
    ans_scope: "打三字",
    ans_prompt: "***",
    ans_result: "中途岛",
    ans_analyze: "*途*",
    difficulty: "1",
    choose: "岛洪中大影合伞为途志忘界"
}, {
    code: "MY000011",
    puzzle: "历史口径最大的战列舰是（）号",
    ans_scope: "打二字",
    ans_prompt: "**",
    ans_result: "大和",
    ans_analyze: "*和",
    difficulty: "1",
    choose: "等为笋春大荣又谈泄更丝和"
}, {
    code: "MY000012",
    puzzle: "舰艇为保持或恢复自身生命力所采取的预防，限制或消除损害的措施简称为（）",
    ans_scope: "打二字",
    ans_prompt: "**",
    ans_result: "损管",
    ans_analyze: "*管",
    difficulty: "1",
    choose: "管拍镜有耐元胜盛目饰清损"
}, {
    code: "MY000013",
    puzzle: "被称为英国皇家海军的荣耀的是（）号战列巡洋舰",
    ans_scope: "打一字",
    ans_prompt: "**",
    ans_result: "胡德",
    ans_analyze: "*德",
    difficulty: "1",
    choose: "午嫁德胡迅红离霍作成迎牙"
}, {
    code: "MY000014",
    puzzle: "世界上最后一艘建成的战列舰是（）号",
    ans_scope: "打三字",
    ans_prompt: "让**",
    ans_result: "让巴尔",
    ans_analyze: "让*尔",
    difficulty: "1",
    choose: "尔子苹果香蕉巴车厘李柿让"
}, {
    code: "MY000015",
    puzzle: "二战吨位最大的航母为（）号",
    ans_scope: "打二字",
    ans_prompt: "**",
    ans_result: "信浓",
    ans_analyze: "信*",
    difficulty: "1",
    choose: "枣苹果香蕉栗子信长不喜浓"
}, {
    code: "MY000016",
    puzzle: "史上参战数量最多的海战是（）海战",
    ans_scope: "打一传统食物",
    ans_prompt: "***",
    ans_result: "日德兰",
    ans_analyze: "日*兰",
    difficulty: "1",
    choose: "汤圆日娘羽两照德色信兰龙"
} ], o = [ {
    code: "121022310001",
    items: [ "MY000001", "MY000002", "MY000003", "MY000004", "MY000005" ]
}, {
    code: "121022310002",
    items: [ "MY000008", "MY000007", "MY000006", "MY000005", "MY000004" ]
}, {
    code: "121022310003",
    items: [ "MY000005", "MY000002", "MY000008", "MY000006", "MY000001" ]
}, {
    code: "121022310004",
    items: [ "MY000002", "MY000004", "MY000006", "MY000008", "MY000001" ]
}, {
    code: "121022310005",
    items: [ "MY000001", "MY000003", "MY000005", "MY000007", "MY000005" ]
}], n = [ {
    code: "221022310001",
    items: [ "MY000009", "MY000010", "MY000011", "MY000012", "MY000013" ]
}, {
    code: "221022310002",
    items: [ "MY000016", "MY000015", "MY000014", "MY000013", "MY000012" ]
}, {
    code: "221022310003",
    items: [ "MY000009", "MY000011", "MY000013", "MY000015", "MY000010" ]
}, {
    code: "221022310004",
    items: [ "MY000010", "MY000012", "MY000014", "MY000016", "MY000011" ]
}, {
    code: "221022310005",
    items: [ "MY000015", "MY000012", "MY000009", "MY000016", "MY000014" ]
}], c = function(s) {
    return 1 === s ? n : o;
}, _ = function(e) {
    return {
        mode: e,
        score: 0,
        numOfCorrect: 0,
        numOfSkipping: 0,
        startTime: s.formatTime(new Date()),
        endTime: "",
        currentIndex: 0,
        items: []
    };
}, l = function(s, e) {
    s.code = e.code, e.items.forEach(function(e) {
        var o = a.find(function(s) {
            return s.code === e;
        });
        if (o) {
            var n = {
                callHelp: !1,
                user_duration: 0,
                user_answer: "",
                user_result: 0
            };
            n.code = o.code, n.puzzle = o.puzzle, n.ans_scope = o.ans_scope, n.ans_prompt = o.ans_prompt, 
            n.ans_result = o.ans_result, n.ans_analyze = o.ans_analyze, n.difficulty = o.difficulty, 
            n.choose = o.choose, s.items.push(n);
        }
    }), s.items.length > 0 && s.items.sort(function() {
        return Math.random() - .5;
    });
};

module.exports = {
    extract: function(s) {
        var e = c(s), a = _(s), o = e.length;
        if (o >= 1) {
            var n = e[this.getNowIndex(s, o)];
            l(a, n);
        }
        return a;
    },
    setNextIndex: function(s) {
        var a = this.getNowIndex(s);
        (a += 1) >= c(s).length && (a = 0);
        try {
            result = 1 == s ? wx.setStorageSync(e.KEY_HARD_GROUP_CURRENT, a) : wx.setStorageSync(e.KEY_EASY_GROUP_CURRENT, a);
        } catch (s) {
            console.log(s);
        }
    },
    getNowIndex: function(a, o) {
        var n = 0;
        try {
            "" == (n = 1 == a ? wx.getStorageSync(e.KEY_HARD_GROUP_CURRENT) : wx.getStorageSync(e.KEY_EASY_GROUP_CURRENT)) && (n = 0), 
            n >= o && (n = 0);
        } catch (e) {
            n = s.randomNum(0, o - 1), console.log(e);
        }
        return n;
    },
    select: function(s, e) {
        var a = c(s).find(function(s) {
            return s.code === e;
        });
        if (a) {
            var o = _(s);
            return l(o, a), o;
        }
        return this.extract(s);
    }
};