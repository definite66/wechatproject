module.exports = {
    VERSION: "1.21.0218",
    KEY_QUESTION_CURRENT: "com.maple.guessing.wx.question.current",
    KEY_EASY_GROUP_CURRENT: "com.maple.guessing.wx.easy.group.current",
    KEY_HARD_GROUP_CURRENT: "com.maple.guessing.wx.hard.group.current"
};