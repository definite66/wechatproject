var t = require("../../utils/config.js"), b = require("./../../utils/guiHelper.js");
const backgroundAudioManager = wx.getBackgroundAudioManager()
backgroundAudioManager.src ='https://636c-cloud1-0gyoose47fbc4007-1324810507.tcb.qcloud.la/images2/%E7%A7%91%E6%99%AE.mp3?sign=611c59cdb7347e8750af56a44054e8de&t=1710755102'
// 背景音乐循环的方法
// 1、onEnded监听播放自然结束
backgroundAudioManager.onEnded(function() {
  // 2、必须重新设置src才能循环之后会自动播放
backgroundAudioManager.src ='https://636c-cloud1-0gyoose47fbc4007-1324810507.tcb.qcloud.la/images2/%E7%A7%91%E6%99%AE.mp3?sign=611c59cdb7347e8750af56a44054e8de&t=1710755102'})
//下载更多资源:airymz.com
Page({
    data: {
        yulu: "",
        randombg: ""
    },
    
    player(audio) {
        var that = this
        //title不写或放空会报错哦，即使不报错ios系统会不播放，所以必须加
        audio.title = 'kepu'
     
        //这点需知微信小程序上线不能超过2M,音乐文件会很大，所以要放在服务器上才可以
        audio.src = 'https://636c-cloud1-0gyoose47fbc4007-1324810507.tcb.qcloud.la/images2/%E7%A7%91%E6%99%AE.mp3?sign=611c59cdb7347e8750af56a44054e8de&t=1710755102'
        
        //音乐播放结束后继续播放此音乐，循环不停的播放
        audio.onEnded(() => {
          that.player(wx.getBackgroundAudioManager())
        })
      },
    onLoad: function(n) {
        this.player(wx.getBackgroundAudioManager())
        var a = n.id, o = t.dataList.filter(function(t) {
            return t.id == a;
        });
        this.setData({
            yulu: o[0]
        });
        var e = "../../img/" + [ Math.floor(9 * Math.random()) ] + ".jpg";
        this.setData({
            randombg: e
        });
    },
    likebtn: function(n) {
        b.audioPlay(1);
        var a = t.dataList.length;
        console.log("yululen:" + a);
        var o = t.dataList, e = Math.floor(Math.random() * a);
        console.log("yuluid:" + e), this.setData({
            yulu: o[e]
        });
        var e = 9, i = "../../img/" + [ Math.floor(Math.random() * e) ] + ".jpg";
        this.setData({
            randombg: i
        });
    },
    onShow: function () {
        //页面显示播放音乐
        this.player(wx.getBackgroundAudioManager())
      },
      onUnload: function() {
        //离开页面是停止播放音乐
        wx.getBackgroundAudioManager().stop();
      },
      onHide: function () {
        //离开页面是停止播放音乐
        wx.getBackgroundAudioManager().stop();
    
      },
});